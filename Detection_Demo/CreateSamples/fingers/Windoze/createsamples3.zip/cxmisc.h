#ifndef __OPENCV_OLD_CXMISC_H__
#define __OPENCV_OLD_CXMISC_H__

#include "internal.hpp"

#endif
